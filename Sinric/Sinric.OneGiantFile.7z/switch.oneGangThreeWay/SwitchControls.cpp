#include "SwitchControls.h"
#include "SinricCallbacks.h" 

/*
void closeSwitch() {
    Serial.println("Switch 1 ('on') ...");
    digitalWrite(LED, LOW);
    digitalWrite(RELAY, HIGH);
}

void openSwitch() {
    Serial.println("Switch 1 ('off') ...");
    digitalWrite(LED, HIGH);
    digitalWrite(RELAY, LOW);
}
*/

void toggleSwitch() {
    Serial.println("Switch 1 toggle...");
    digitalWrite(LED, HIGH);
    digitalWrite(RELAY, !digitalRead(RELAY));
}


void sinricOn(String deviceId, boolean lightState) {
  if (deviceId == DEVICE_ID) // Device ID of first device
  {  
    Serial.print("Turn on device id: ");
    Serial.print(deviceId);
    if (!lightState) { toggleSwitch(); Serial.println("-OK"); } else { Serial.println("...Current flow indicates circuit already closed."); }
  } else {
    Serial.print("Turn on for unknown device id: ");
    Serial.println(deviceId);    
  }     
}

void sinricOff(String deviceId, boolean lightState) {
   if (deviceId == DEVICE_ID) // Device ID of first device
   {  
     Serial.print("Turn off Device ID: ");
     Serial.print(deviceId);
     if (lightState) { toggleSwitch(); Serial.println("-OK"); } else { Serial.println("...Current flow indicates circuit already open."); }
   } else {
     Serial.print("Turn off for unknown device id: ");
     Serial.println(deviceId);    
  }
}
