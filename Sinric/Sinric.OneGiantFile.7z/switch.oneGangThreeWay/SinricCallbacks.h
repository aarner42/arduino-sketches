#ifndef SINRICCALLBACKS_H
#define SINRICCALLBACKS_H

#include <Arduino.h>
#include <WebSocketsClient.h> 
#include <ArduinoJson.h> 

#include <StreamString.h>


void setPowerStateOnServer(String deviceId, String value, WebSocketsClient webSocket);

#endif
