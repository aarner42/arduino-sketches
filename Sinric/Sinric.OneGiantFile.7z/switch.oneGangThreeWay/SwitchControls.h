#ifndef SWITCHCONTROLS_H
#define SWITCHCONTROLS_H

#define DEVICE_ID "5c3944433a54d866e07086c7"  // deviceId is the ID assgined to your smart-home-device in sinric.com dashboard. Copy it from dashboard and paste it here
#define LAN_HOSTNAME  "TangoWhiskeyTwo"

/************ define pins *********/
#define RELAY   D1   // D1 drives 120v relay
#define CONTACT D3   // D3 connects to momentary switch
#define LED D4       // D4 powers switch illumination

#include <Arduino.h>

//void closeSwitch();
//void openSwitch();
void toggleSwitch();
void sinricOn(String deviceID, boolean lightState);
void sinricOff(String deviceID, boolean lightState);
 

#endif
