#include "SinricCallbacks.h"

 


// Call ONLY If status changed manually. DO NOT CALL THIS IN loop() and overload the server. 
void setPowerStateOnServer(String deviceId, String value, WebSocketsClient webSocket) {
  Serial.print("Updating status on server.  Setting deviceID:");
  Serial.print(deviceId);
  Serial.print(" new state:");
  Serial.println(value);
  DynamicJsonBuffer jsonBuffer;
  JsonObject& root = jsonBuffer.createObject();
  root["deviceId"] = deviceId;
  root["action"] = "setPowerState";
  root["value"] = value;
  StreamString databuf;
  root.printTo(databuf);
  webSocket.sendTXT(databuf);
  
}



